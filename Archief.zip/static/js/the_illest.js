var socket = new io();

socket.on('connect', function() {
    socket.emit('enter', '');
})
var mapdata;


var receiver = document.querySelector(".chatbox");
var intel_box = document.querySelector('.intel_box');

socket.on('swag', function(data) {
    receiver.innerHTML += "<br>" + data;
});

socket.on('intel', function(data){
    intel_box .innerHTML += "<br>" + data;
});
socket.on('game', function(data){
    if(data.length > 0){
        mapdata = data;
        draw();
    }else {
        document.querySelector(".current_location").innerHTML = "x: " + data.x + " y:" + data.y;

    }
    console.log(data.length);
    

});
var inputter = document.querySelector("#inputter");
var nicker = document.querySelector("#nicker");

nicker.addEventListener('keypress', (keycode) => {
    if(keycode.which == 13){
        socket.emit('nickname', nicker.value);
        nicker.outerHTML = '';
    }
});
inputter.addEventListener('keypress', (keycode) => {
    if(keycode.which == 13){
        socket.emit('swag', inputter.value);
        inputter.value = "";

    }
})

window.addEventListener('keydown', (keycode) => {
    console.log("press" + keycode.which);
    /* up */
    if(keycode.which == 38){
        socket.emit('move', 'up');
    }
    /* right */
    else if(keycode.which == 39){
        socket.emit('move', 'right');

    }
    /* left */
    else if(keycode.which == 37){
        socket.emit('move', 'left');

    }
    /* down */
    else if(keycode.which == 40){
        socket.emit('move', 'down');

    }
})


function draw() {
    var canvas = document.getElementById("game_map");
    var ctx = document.getElementById('game_map').getContext('2d');
    

    var w = 500;
    var h = 500;
    var tile = Math.floor(w / 9);

    ctx.clearRect(0, 0, w, h); // clear canvas

    for(var i = 0; i < mapdata.length; i++){
        for(var j = 0; j < mapdata[i].length; j++){
            var start_x = Math.floor(i * tile);
            var start_y = Math.floor(j * tile);

            if(mapdata[i][j] == 1){
                ctx.fillStyle = 'green';                
                ctx.fillRect(start_x, start_y, tile, tile);                
                ctx.save();
                ctx.restore();
            }
            if(mapdata[i][j] == 2){
                ctx.fillStyle = 'red';
                ctx.fillRect(start_x, start_y, tile, tile);
                ctx.save();
                ctx.restore();
            }
            
            
            
            
        }
    }

    window.requestAnimationFrame(draw);

}



